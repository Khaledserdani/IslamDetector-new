package com.islamdetector.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
  private LinearLayout root; private TextView deviceState, deviceResult, aiResult, calibration; private boolean searching=false;
  @Override public void onCreate(Bundle state){super.onCreate(state); getWindow().setStatusBarColor(Color.rgb(7,18,29)); buildInterface();}
  private void buildInterface(){
    ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(Color.rgb(7,18,29));
    root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER_HORIZONTAL); root.setPadding(dp(16),dp(18),dp(16),dp(28)); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); scroll.addView(root,new ScrollView.LayoutParams(-1,-1));
    TextView title=text("إسلام لكشف المعادن",25,Color.rgb(244,185,66),true); title.setGravity(Gravity.CENTER); root.addView(title,matchWrap(0,12));
    TextView sub=text("الإصدار التجريبي 0.1 • واجهة محلية آمنة",14,Color.rgb(158,179,196),false); sub.setGravity(Gravity.CENTER); root.addView(sub,matchWrap(0,18));
    deviceState=card("حالة الجهاز","غير متصل\nسيستمر التطبيق محلياً حتى ربط وحدة ESP32-S3",Color.rgb(48,209,139));
    calibration=card("التصفير والمعايرة","0% • في انتظار الاتصال",Color.rgb(244,185,66));
    deviceResult=card("نتيجة الجهاز","لا توجد إشارة بعد\nالكشف الخام له الأولوية ولا يتم كتم الهدف المحتمل",Color.WHITE);
    aiResult=card("تحليل الذكاء الاصطناعي","في انتظار بيانات حقيقية\nللتحليل والاقتراح فقط • التحكم والحماية بيد المعالج",Color.WHITE);
    Button start=button("بدء البحث"); start.setOnClickListener(v->{searching=!searching; start.setText(searching?"إيقاف البحث":"بدء البحث"); deviceResult.setText(searching?"الجهاز\nوضع البحث نشط • في انتظار إشارة الجهاز":"نتيجة الجهاز\nتم إيقاف البحث يدوياً"); toast(searching?"بدأ وضع البحث":"توقف وضع البحث");}); root.addView(start,match(dp(56),8));
    LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); Button rescan=button("إعادة المسح"), save=button("حفظ القراءة"); rescan.setOnClickListener(v->toast("جاهز لإعادة المسح متعدد الاتجاهات")); save.setOnClickListener(v->toast("سيُفعّل الحفظ عند وصول بيانات الجهاز")); row.addView(rescan,weight()); row.addView(save,weight()); root.addView(row,matchWrap(0,8));
    Button dig=button("تسجيل نتيجة الحفر"); dig.setOnClickListener(v->toast("سيُفعّل سجل الحفر في الإصدار التالي")); root.addView(dig,match(dp(54),0)); setContentView(scroll);
  }
  private TextView card(String heading,String body,int accent){TextView v=text(heading+"\n"+body,16,Color.WHITE,false); v.setLineSpacing(0,1.18f); v.setPadding(dp(16),dp(14),dp(16),dp(14)); GradientDrawable g=new GradientDrawable(); g.setColor(Color.rgb(16,37,54)); g.setCornerRadius(dp(15)); g.setStroke(dp(1),accent); v.setBackground(g); root.addView(v,matchWrap(0,12)); return v;}
  private Button button(String label){Button b=new Button(this); b.setText(label); b.setTextSize(16); b.setTextColor(Color.rgb(7,18,29)); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setAllCaps(false); GradientDrawable g=new GradientDrawable(); g.setColor(Color.rgb(244,185,66)); g.setCornerRadius(dp(14)); b.setBackground(g); return b;}
  private TextView text(String s,int size,int color,boolean bold){TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color); if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v;}
  private LinearLayout.LayoutParams match(int h,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,h); p.bottomMargin=dp(bottom); return p;}
  private LinearLayout.LayoutParams matchWrap(int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(top); p.bottomMargin=dp(bottom); return p;}
  private LinearLayout.LayoutParams weight(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(54),1); p.setMargins(dp(4),0,dp(4),0); return p;}
  private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
  private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
