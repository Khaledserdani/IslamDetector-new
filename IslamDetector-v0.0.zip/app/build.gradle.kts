plugins { id("com.android.application") }

android {
    namespace = "com.islamdetector.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.islamdetector.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
